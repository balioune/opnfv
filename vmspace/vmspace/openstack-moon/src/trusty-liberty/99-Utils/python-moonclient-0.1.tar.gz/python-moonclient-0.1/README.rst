Moon Client
===========

Installation
------------

* `sudo python setup.py install`

* `cd ~/devstack || source openrc admin`


Manipulation
------------

* `moon tenant list`


